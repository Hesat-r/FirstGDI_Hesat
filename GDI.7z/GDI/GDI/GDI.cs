﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GDI
{
    public partial class GDI : Form
    {
        public GDI()
        {
            InitializeComponent();
        }

        private void GDI_Paint(object sender, PaintEventArgs e)
        {
            ResizeRedraw = true;
            Graphics g = e.Graphics;
            Pen p = new Pen(Color.Red, 3);
            Pen p2 = new Pen(Color.DarkGreen, 3);
            Pen p3 = new Pen(Color.DarkBlue, 3);
            int width = this.ClientSize.Width;
            int height = this.ClientSize.Height;
            int x1 = width/2;
            int x2 = width/2;
            int y1 = 0;
            int y2 = height;
           //gerader strich
            g.DrawLine(p, x1, y1, x2, y2);
            // dreieck
            g.DrawLine(p2, x1, y1, width, height);
            g.DrawLine(p2, x1, y1, 0, height);
            g.DrawLine(p2, width, height, 0, height);
            //kreis
            g.DrawEllipse(p3, width/4, height/4, width/4*2,height/4*3);
            
        }
    }
}
